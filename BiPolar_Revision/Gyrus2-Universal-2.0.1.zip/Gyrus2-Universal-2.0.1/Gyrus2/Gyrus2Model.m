//
//  Gyrus2Model.m
//  Gyrus2
//
//  Created by James Hollender on 1/2/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Gyrus2Model.h"

@implementation Gyrus2Model

@synthesize outcome;
@synthesize procedure;
@synthesize productLine;
@synthesize product;
@synthesize author;
@synthesize competingProcess;
@synthesize paperType;
@synthesize articleTitle;
@synthesize reference;
@synthesize outcomeOrComments;
@synthesize abstract;
@synthesize hyperlink;
@synthesize listType;

@end
