//
//  InfoViewController_iPad.h
//  Gyrus2
//
//  Created by James Hollender on 3/25/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InfoViewController_iPad : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *labelVersion;

- (IBAction)doneButtonTap:(id)sender;

@end
