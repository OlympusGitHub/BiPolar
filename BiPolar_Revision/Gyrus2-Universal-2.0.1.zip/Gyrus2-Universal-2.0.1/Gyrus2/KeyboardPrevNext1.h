//
//  KeyboardPrevNext1.h
//  VIM
//
//  Created by James Hollender on 1/29/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#ifndef VIM_KeyboardPrevNext1_h
#define VIM_KeyboardPrevNext1_h

UIToolbar *toolbarKeyboard;
NSArray *arrayFields;
BOOL noNavBar;

#endif
