//
//  FirstViewController_iPad.h
//  Gyrus2
//
//  Created by James Hollender on 3/25/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "InfoViewController_iPad.h"

@interface FirstViewController_iPad : UIViewController

- (IBAction)buttonInfoTap:(id)sender;

@end
